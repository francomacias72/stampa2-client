import React from 'react';
import './App.css';
import Footer from './components/Footer';
import Forma from './components/Forma';
import Header from './components/Header';


// import Header from './components/Header'



function App() {
  return (
    <div>
      <Header />
      <Forma />
      <Footer />
    </div>
  );
}

export default App;
