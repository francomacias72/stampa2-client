import React from 'react'
import '../App.css'
// import logo from './sustaita-logo.PNG'

export default function Header() {
    return (
        <div className='header text-center' style={{ letterSpacing: '3px' }}>
            <h2>IMPRIMIR ETIQUETA</h2>
        </div>
    )
}
